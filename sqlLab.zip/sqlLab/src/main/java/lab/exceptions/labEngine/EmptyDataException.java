package lab.exceptions.labEngine;

public class EmptyDataException extends RuntimeException {
    public EmptyDataException(String message){
        super(message);
    }
}
