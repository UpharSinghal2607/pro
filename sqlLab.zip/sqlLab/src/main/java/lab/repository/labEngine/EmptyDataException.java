package lab.repository.labEngine;

public class EmptyDataException extends RuntimeException {
    EmptyDataException(String message){
        super(message);
    }
}
