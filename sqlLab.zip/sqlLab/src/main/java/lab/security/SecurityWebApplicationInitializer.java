package lab.security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;


/*
this class enable the spring security framework
 */
public class SecurityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

}
