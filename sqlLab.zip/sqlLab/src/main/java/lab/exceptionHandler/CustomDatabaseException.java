package lab.exceptionHandler;

public class CustomDatabaseException extends Exception {
    public CustomDatabaseException(String message) {
        super(message);
    }

    public CustomDatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}
