package lab.entity.questionBank;

public enum DeleteStatus {

    TRUE,
    FALSE

}
