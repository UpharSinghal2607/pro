package lab.entity.questionBank;

public enum QuestionDifficulty {

    EASY,
    MEDIUM,
    HARD

}
