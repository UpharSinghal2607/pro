package lab.entity.user;

public enum Role {
    ROLE_ADMIN,
    ROLE_TRAINEE
}
