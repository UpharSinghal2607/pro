package lab.entity.user;

public enum UserStatus {

    ACTIVE,
    INACTIVE

}
