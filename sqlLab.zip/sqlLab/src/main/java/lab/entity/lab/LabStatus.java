package lab.entity.lab;

public enum LabStatus {
    UNATTEMPTED,
    RESUME,
    COMPLETED
}
