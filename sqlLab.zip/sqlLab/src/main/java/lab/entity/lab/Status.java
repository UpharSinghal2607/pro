package lab.entity.lab;

public enum Status {
    SKIP,
    INCORRECT,
    CORRECT,
    UNATTEMPTED
}
