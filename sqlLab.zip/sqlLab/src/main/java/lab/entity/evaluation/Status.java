package lab.entity.evaluation;


public enum Status {
    SKIP,
    INCORRECT,
    CORRECT,
    UNATTEMPTED
}
