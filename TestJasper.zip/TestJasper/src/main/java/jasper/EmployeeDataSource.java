package jasper;

import entity.Employee;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDataSource {
    public static List<Employee> createEmployeeList() {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(1, "John Doe", "Engineering", 50000));
        employees.add(new Employee(2, "Jane Smith", "Marketing", 45000));
        employees.add(new Employee(3, "Alice Johnson", "HR", 55000));
        return employees;
    }
}