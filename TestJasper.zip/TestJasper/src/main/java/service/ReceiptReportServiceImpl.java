package service;

import dao.ReceiptDao;
import entity.Receipt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.sql.Date;
import java.util.List;

@Service
@Transactional
public class ReceiptReportServiceImpl implements ReceiptReportService
{

    @Autowired
    ReceiptDao receiptReportService;


    @Override
    public List<Receipt> getallReceipt() {
        return receiptReportService.getallReceipt();
    }

    @Override
    public List<Receipt> getallReceiptbyID(Long id) {
        return receiptReportService.getallReceiptbyID(id);
    }

    @Override
    public List<Receipt> getallReceiptbyLoanACC(String id, Date fromdate, Date todate) {
        return receiptReportService.getallReceiptbyLoanACC(id,fromdate,todate);
    }
}
