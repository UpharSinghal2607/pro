package dao;

import entity.Employee;
import entity.Receipt;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.sql.Date;
import java.util.List;

@Repository
public class ReceiptDaoImpl implements ReceiptDao{
@Autowired
    SessionFactory sessionFactory;

    @Autowired
    public ReceiptDaoImpl(SessionFactory factory){this.sessionFactory=factory;}





    @Override
    public List<Receipt> getallReceipt() {
        List<Receipt> customerList;
        Session session = sessionFactory.getCurrentSession();
        customerList=session.createQuery("from Receipt",Receipt.class).getResultList();
        return customerList;    }
    @Override
    public List<Receipt> getallReceiptbyID(Long id) {
        List<Receipt> customerList;
        Session session = sessionFactory.getCurrentSession();
        customerList=session.createQuery("from Receipt where receiptId=?1",Receipt.class).setParameter(1,id).getResultList();
        return customerList;    }

    @Override
    public List<Receipt> getallReceiptbyLoanACC(String id, Date fromdate,Date todate) {
        List<Receipt> customerList;
        Session session = sessionFactory.getCurrentSession();
        customerList=session.createQuery("from Receipt where loanAccountNumber=?1 and dateOfReceipt BETWEEN ?2 AND ?3",Receipt.class).setParameter(1,id).setParameter(2,fromdate).setParameter(3,todate).getResultList();
        return customerList;    }
}
