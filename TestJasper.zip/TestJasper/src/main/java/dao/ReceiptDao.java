package dao;

import entity.Employee;
import entity.Receipt;

import java.sql.Date;
import java.util.List;

public interface ReceiptDao {

    List<Receipt> getallReceipt();
    public List<Receipt> getallReceiptbyID(Long id);
    public List<Receipt> getallReceiptbyLoanACC(String id, Date fromdate, Date todate);

}
