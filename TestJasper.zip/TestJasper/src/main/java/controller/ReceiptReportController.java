package controller;

import LogFactory.LogFactory;
import dao.ReceiptDao;
import entity.Employee;
import entity.Receipt;
import jasper.EmployeeDataSource;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleWriterExporterOutput;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import service.ReceiptReportService;

import java.io.*;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


@Controller
public class ReceiptReportController {
    private static final Logger logger= LogFactory.getInstance();



@Autowired
ReceiptReportService receiptReportService;

    @PostMapping(value = "/receipt-report")
    public String start()
    {
        return "views/ReceiptReportMain.jsp";
    }

    @PostMapping(value = "/form")
    public String process(Model model,@RequestParam String loanacc,
                          @RequestParam String fromdate,
                          @RequestParam String todate,
                          @RequestParam Long ReceiptNo) {
//        List<Receipt> list=receiptReportService.getallReceipt();
        List<Receipt> list=new ArrayList<>();
        if(ReceiptNo!=null && ReceiptNo!=0)
        {
            list=receiptReportService.getallReceiptbyID(ReceiptNo);
        } else
        {
                list=receiptReportService.getallReceiptbyLoanACC(loanacc,Date.valueOf(fromdate),Date.valueOf(todate));

        }
        System.out.println(list);
        model.addAttribute("list",list);
        model.addAttribute("show",true);
        return "views/ReceiptReportMain.jsp";
    }


    public JasperPrint task(Long id) {
        JasperPrint jasperPrint=null;
        try {


            // Load employee data
            List<Receipt> list = receiptReportService.getallReceiptbyID(id);
            Map<String, Object> parameters = new HashMap<String, Object>();
            // parameters.put("CurrentDate",LocalDate.now());
            // Compile jrxml file
            JasperCompileManager.compileReportToFile("C:\\Users\\uphar.singhal\\IdeaProjects\\TestJasper\\src\\main\\resources\\Report.jrxml");

            // Fill the report with data
             jasperPrint = JasperFillManager.fillReport("C:\\Users\\uphar.singhal\\IdeaProjects\\TestJasper\\src\\main\\resources\\Receipt.jasper", parameters, new JRBeanCollectionDataSource(list));
        } catch (JRException e) {
           logger.error(e);
        }
        return jasperPrint;

    }
        @PostMapping("/getPDF/{id}")
    public String exe(@PathVariable Long id,Model model){
        List<Receipt> list=receiptReportService.getallReceiptbyID(id);
        Receipt receipt=list.get(0);
        System.out.println(list);
        model.addAttribute("list",list);
        model.addAttribute("show",true);
        return "../views/ReceiptReportSecond.jsp";
    }
    @PostMapping(value="/getCSV/{id}")
    public String csv(@PathVariable Long id) {
        try{
            JRCsvExporter exporter = new JRCsvExporter();
            exporter.setExporterInput(new SimpleExporterInput(task(id)));
            exporter.setExporterOutput(new SimpleWriterExporterOutput(new FileOutputStream("C:\\Users\\uphar.singhal\\Documents\\"+id+".csv")));
            exporter.exportReport();

            System.out.println("Report generated successfully!");

        }catch (JRException e) {
            logger.error(e);
        } catch (FileNotFoundException e) {
            logger.error(e);
        }
        return "../views/ReceiptReportMain.jsp";
    }
    @PostMapping(value="/getXLS/{id}")
    public String xls(@PathVariable Long id) {
        try{
            JRXlsExporter exporter = new JRXlsExporter();
            exporter.setExporterInput(new SimpleExporterInput(task(id)));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(new FileOutputStream("C:\\Users\\uphar.singhal\\Documents\\"+id+".xls")));
            exporter.exportReport();
            System.out.println("Report generated successfully!");

        }catch (JRException e) {
            logger.error(e);
        } catch (FileNotFoundException e) {
            logger.error(e);
        }
        return "../views/ReceiptReportMain.jsp";
    }
    @PostMapping(value="/getPDFDownload/{id}")
    public String pdf(@PathVariable Long id)
    {
       try{
            String outputFile = "C:\\Users\\uphar.singhal\\Documents\\"+id+".pdf";
            // Export to PDF
            OutputStream outputStream = new FileOutputStream(new File(outputFile));
            JasperExportManager.exportReportToPdfStream(task(id), outputStream);
              System.out.println("Report generated successfully!");
        }catch (JRException e) {
           logger.error(e);
        } catch (FileNotFoundException e) {
           logger.error(e);
        }
        return "../views/ReceiptReportMain.jsp";
    }
}
