package LogFactory;

import org.apache.log4j.Logger;

//  ~~~~~~~~~~~~~~~~~~~~~~~~UPHAR SINGHAL 17261 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
public class LogFactory {
    private static Logger logger=null;
   private LogFactory(){

    }
    public static Logger getInstance()
    {
        if(logger==null)
        {
            logger=Logger.getLogger("mylogs");
        }
        return logger;
    }
}
