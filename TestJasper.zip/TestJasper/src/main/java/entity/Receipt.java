package entity;

import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.sql.Date;
@Entity
@Component
@Table(name = "Receipt_Tbl17261")
public class Receipt {

        @Id
        @GeneratedValue(strategy = GenerationType.SEQUENCE)
        private Long receiptId;
        private String loanAccountNumber;
        private Double transactionAmount;
        private Date transactionDate;
        @Enumerated(EnumType.STRING)
        private Currency currency;
        private Date dateOfReceipt;
    @Enumerated(EnumType.STRING)

        private PaymentMode paymentMode;
        private Double requiredAmount;
        private String instrumentNumber;
        private Date instrumentDate;
        private String receivedfrom;
        private String receiptbasis;
        private String bankName;
        @Enumerated(EnumType.STRING)
        private ReceiptStatus status;
        @Enumerated(EnumType.STRING)
        private RecordStatus recordStatus;


    public Long getReceiptId() {
        return receiptId;
    }

    public void setReceiptId(Long receiptId) {
        this.receiptId = receiptId;
    }

    public String getLoanAccountNumber() {
        return loanAccountNumber;
    }

    public void setLoanAccountNumber(String loanAccountNumber) {
        this.loanAccountNumber = loanAccountNumber;
    }

    public Double getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(Double transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        this.transactionDate = transactionDate;
    }

    public Currency getCurrency() {
        return currency;
    }

    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public Date getDateOfReceipt() {
        return dateOfReceipt;
    }

    public void setDateOfReceipt(Date dateOfReceipt) {
        this.dateOfReceipt = dateOfReceipt;
    }

    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public Double getRequiredAmount() {
        return requiredAmount;
    }

    public void setRequiredAmount(Double requiredAmount) {
        this.requiredAmount = requiredAmount;
    }

    public String getInstrumentNumber() {
        return instrumentNumber;
    }

    public void setInstrumentNumber(String instrumentNumber) {
        this.instrumentNumber = instrumentNumber;
    }

    public Date getInstrumentDate() {
        return instrumentDate;
    }

    public void setInstrumentDate(Date instrumentDate) {
        this.instrumentDate = instrumentDate;
    }

    public String getReceivedfrom() {
        return receivedfrom;
    }

    public void setReceivedfrom(String receivedfrom) {
        this.receivedfrom = receivedfrom;
    }

    public String getReceiptbasis() {
        return receiptbasis;
    }

    public void setReceiptbasis(String receiptbasis) {
        this.receiptbasis = receiptbasis;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public ReceiptStatus getStatus() {
        return status;
    }

    public void setStatus(ReceiptStatus status) {
        this.status = status;
    }

    public RecordStatus getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(RecordStatus recordStatus) {
        this.recordStatus = recordStatus;
    }



    @Override
    public String toString() {
        return "Receipt{" +
                "receiptId=" + receiptId +
                ", loanAccountNumber='" + loanAccountNumber + '\'' +
                ", transactionAmount=" + transactionAmount +
                ", transactionDate=" + transactionDate +
                ", currency=" + currency +
                ", dateOfReceipt=" + dateOfReceipt +
                ", paymentMode=" + paymentMode +
                ", requiredAmount=" + requiredAmount +
                ", instrumentNumber='" + instrumentNumber + '\'' +
                ", instrumentDate=" + instrumentDate +
                ", receivedfrom='" + receivedfrom + '\'' +
                ", receiptbasis='" + receiptbasis + '\'' +
                ", bankName='" + bankName + '\'' +
                ", status=" + status +
                ", recordStatus=" + recordStatus +
              //  ", receivablePayable=" + receivablePayable +
                '}';
    }
}
