package entity;

public enum RecordStatus {
    APPROVED
}
