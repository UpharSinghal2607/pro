package entity;

public enum Currency {
    INR
}
