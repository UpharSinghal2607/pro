package entity;

public enum ReceiptStatus {
    APPROVED
}
