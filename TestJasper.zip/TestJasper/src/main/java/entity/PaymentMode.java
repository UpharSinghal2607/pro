package entity;

public enum PaymentMode {
    Draft
}
